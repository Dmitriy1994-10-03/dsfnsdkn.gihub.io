/**
 * Created by vojtech.esner on 12.06.14.
 */
jQuery(function() {
    jQuery("#views-exposed-form-recipes-page-5 input, #views-exposed-form-recipes-page-4 input").attr("placeholder", "Vyhledat recept..");
    jQuery('#edit-search-api-views-fulltext').after('<div id="myResults" style="display:none"></div>');
    //jQuery('input[name=search_api_views_fulltext]').keyup(function() {
    //    var val = jQuery('input[name=search_api_views_fulltext]').val();
    //    if(val.length >= 3){
    //        jQuery.getJSON("/collection-search/"+val,
    //        function(data){
    //
    //            var myArray = [];
    //
    //            jQuery.each(data.nodes,function(index,item){
    //                myArray.push(item.node.title);
    //
    //            });
    //
    //            if(myArray.length > 0){
    //                jQuery('#myResults').html('');
    //                jQuery('#myResults').show();
    //                jQuery.each(myArray,function(index,item){
    //
    //                      jQuery('#myResults').append(item+"<br />");
    //
    //                });
    //            } else {
    //                jQuery('#myResults').html('');
    //                jQuery('#myResults').hide();
    //            }
    //        });
    //    } else {
    //        jQuery('#myResults').html('');
    //        jQuery('#myResults').hide();
    //
    //    }
    //});
    jQuery('.bef-checkboxes input:checkbox').removeAttr('checked');
    /*Toogle mobile-menu*/
    jQuery('#menu-icon').click(function() {
        jQuery('#login1').hide();
        jQuery('#advancedSearch-content').hide();
        jQuery('#primary_nav').slideToggle(300, 'easeOutQuint');
    });

    /*Toogle login-menu*/
    jQuery('div#login-icon').click(function() {
        jQuery('#primary_nav').hide();
        jQuery('#advancedSearch-content').hide();
        jQuery('#login1').slideToggle(300, 'easeOutQuint');
    });

    /*Toogle search-advanced*/
    jQuery('#advancedSearch-title a').unbind("click");
    jQuery('#advancedSearch-title a').click(function() {
        jQuery('#login1').hide();
        jQuery('#primary_nav').hide();
        jQuery('#advancedSearch-content').slideToggle(300, 'easeOutQuint');
    });

    /*Toogle taxonomy-filter-menu*/
    jQuery('#taxonomy-filter-menu-toggle').click(function() {
        jQuery('#taxonomy-filter-menu').slideToggle(300, 'easeOutQuint');
        jQuery('#taxonomy-filter-menu-toggle').toggleClass('opened');
    });

    jQuery(document).bind('flagGlobalAfterLinkUpdate', function(event, data) {
        if (data.flagName == 'user_cookbook') {
            jQuery('#recipe-icon-kuchar').toggleClass('recipe-icon-kuchar-pridat recipe-icon-kuchar-odebrat');
        }
    });

    function resize() {
        var $width = jQuery("#videonavod").width();
        var $height = ($width / 1.7);
        jQuery("#videonavod").height($height);
    }
    jQuery(window).resize(function() {
        resize();
    });
    resize();

    var skyscraper_right_height = jQuery('.skyscraper_right').height();
    if (skyscraper_right_height <= 18) {
        jQuery('.skyscraper_right').hide();
    }


});

jQuery(document).ready(

    function() {
        //    jQuery('.searchIconw').click(function(){
        // if (jQuery('#search-wrapper').css('visibility') == 'hidden' )
        //   jQuery('#search-wrapper').css('visibility','visible')+
        //   jQuery('#search-wrapper').css('opacity','1');
        //
        // else
        //   jQuery('#search-wrapper').css('visibility','hidden')+
        //   jQuery('#search-wrapper').css('opacity','0');
        //
        //     if (jQuery('#login').css('visibility') == 'visible' )
        //   jQuery('#login').css('visibility','hidden')+
        //   jQuery('#login').css('opacity','0');
        //
        //   setTimeout(function() {
        //       jQuery('#edit-search-api-views-fulltext').focus();
        //       }, 666);
        //    });


    if(window.location.href === "https://www.apetitonline.cz/edice"){
        jQuery(".strossle-widget-article").hide();
    }

    if(window.location.href === "https://www.apetitonline.cz/aktivace"){
        jQuery(".webform-submit").hide();
    }

    // presunutie reklamy priamo pod recept
    jQuery(".1-5-8").insertBefore("#comments");

    if (jQuery(".priprava-wrapper")[0]){
        jQuery(".priprava-wrapper").each(function () {
            var preparation = jQuery(this);
            var paragraph = preparation.find("p");
            var numberOfParagraph = paragraph.length;
            var preparationFirstParagraph = paragraph.first();
            var preparationSecondParagraph = preparationFirstParagraph.next();

            if (numberOfParagraph < 3) {
                jQuery( ".recipe-container" ).insertAfter(preparationFirstParagraph);
            }

            if (numberOfParagraph > 2) {
                jQuery( ".recipe-container" ).insertAfter(preparationSecondParagraph);
            }
        });
    }

    // fixed megaborad on scroll
    jQuery(window).on('scroll',function() {
        var lastScrollTop = 0;
        var currentScroll = jQuery(window).scrollTop();
        var megaboard = jQuery(".bmone2n-21676-1-5-1");
        var megaboardReached = megaboard.offset().top;
        if (currentScroll >= megaboardReached) {
            if (jQuery(window).width() < 992) {
                megaboard.addClass("megaboard-fixed");
                megaboard.addClass("megaboard-mobile");
            }
            else {
                megaboard.addClass("megaboard-fixed");
                megaboard.addClass("megaboard-desktop");
            }
        }
        if (jQuery(window).width() < 992) {
            if (currentScroll >= 600)  {
                megaboard.addClass("megaboard-relative");
            }
        }
        else {
            if (currentScroll >= 1300)  {
                megaboard.addClass("megaboard-relative");
            }
        }
        if (megaboard.hasClass("megaboard-fixed")) {
            jQuery(window).on('scroll', function() {
                st = jQuery(this).scrollTop();
                if(st < lastScrollTop) {
                    megaboard.addClass("megaboard-relative");
                }
                else {
                }
                lastScrollTop = st;
            });
        }
    });

    // pridany parameter na odkaz k suvisiacemu clanku
    var _href = jQuery(".similar-article-link").attr("href");
    jQuery(".similar-article-link").attr("href", _href + '?utm_source=www.apetitonline.cz&utm_medium=sharing_widget');

	// po hover na info ikonu na detailu clanku sa ukaze zdroj obrazku
	jQuery(".article-icon").mouseover(function(){
	  jQuery(".article-icon-image").css({ "transition": ".25s all ease", "display": "block" });
	});

	jQuery(".article-icon-image").mouseleave(function(){
	  jQuery(".article-icon-image").css("display","none");

	  jQuery(".article-icon").css("display","block");
	});
	
        jQuery('.profileIconw').click(function() {
            if (jQuery('#login').css('visibility') == 'hidden')
                jQuery('#login').css('visibility', 'visible') +
                jQuery('#login').css('opacity', '1');
            else
                jQuery('#login').css('visibility', 'hidden') +
                jQuery('#login').css('opacity', '0');
        });
        jQuery(".bef-secondary-options > label").click(function() {
            jQuery(this).toggleClass("active");
        });

        //veggie switcher active
        if (window.location.href.indexOf("veggie?field_veggie_tid=441") > -1) {
            jQuery(".veggie-filter-check a").removeClass("active");
            jQuery(".veggie-filter-check a.veggie_vegan").addClass("active");
        } else if (window.location.href.indexOf("veggie") > -1) {
            jQuery(".veggie-filter-check a").removeClass("active");
            jQuery(".veggie-filter-check a.veggie_all").addClass("active");
        }

        //
        //         jQuery('#srch-icon').click(function(){
        // if (jQuery('#search-wrapper').css('visibility') == 'hidden' )
        //   jQuery('#search-wrapper').css('visibility','visible')+
        //   jQuery('#search-wrapper').css('opacity','1');
        // else
        //   jQuery('#search-wrapper').css('visibility','hidden')+
        //   jQuery('#search-wrapper').css('opacity','0');
        //    });

        jQuery("form #edit-name").attr("placeholder", "Přihlašovací jméno");
        jQuery("form #edit-name").prop('required', true);
        jQuery("form #edit-pass").attr("placeholder", "Heslo");
        jQuery("#edit-search-api-views-fulltext").attr("placeholder", "Hledat");
        jQuery("form #edit-pass").prop('required', true);

        jQuery(document).click(function(e) {

            var target = jQuery(e.target),
                article;
            if (target.is('.profileIconw') || target.is('.searchIconw') || target.is('#advancedSearch-title a') || target.is('#srch-icon') || target.is('#advancedSearch-content *')) {
                return;
            };

            if (jQuery('#search-wrapper').css('visibility') == 'visible')
                // jQuery('#search-wrapper').css('visibility','hidden')+
                // jQuery('#search-wrapper').css('opacity','0')+
                jQuery('.social').css('visibility', 'visible') +
                jQuery('.social').css('opacity', '1');
            else if (jQuery('#login').css('visibility') == 'visible')
                jQuery('#login').css('visibility', 'hidden') +
                jQuery('#login').css('opacity', '0');
        });
        jQuery('#edit-search-api-views-fulltext').click(function(event) {
            event.stopPropagation();
        });
        jQuery('#login').click(function(event) {
            event.stopPropagation();
        });
        jQuery('#srch-icon').click(function(event) {
            event.stopPropagation();
        });


    });
(function(jQuery, Drupal, window, document, undefined) {
    //Configure colorbox call back to resize with custom dimensions
    jQuery.colorbox.settings.onLoad = function() {
        colorboxResize();
    }

    //Customize colorbox dimensions
    var colorboxResize = function(resize) {
        var width = "90%";
        var height = "90%";

        if (jQuery(window).width() > 960) {
            width = "860"
        }
        if (jQuery(window).height() > 700) {
            height = "630"
        }

        jQuery.colorbox.settings.height = height;
        jQuery.colorbox.settings.width = width;

        //if window is resized while lightbox open
        if (resize) {
            jQuery.colorbox.resize({
                'height': height,
                'width': width
            });
        }
    }

    //In case of window being resized
    jQuery(window).resize(function() {
        colorboxResize(true);
    });
	
	/*apetit tv carousel */
	 //jQuery('.apetittv-video-slider-wrap').jcarousel();
	 jQuery(function() {
        jQuery('.apetittv-video-slider-wrap')
        .on('jcarousel:create jcarousel:reload', function() {
        var element = jQuery(this),
            width = element.innerWidth();

        // This shows 1 item at a time.
        // Divide `width` to the number of items you want to display,
        // eg. `width = width / 3` to display 3 items at a time.
        element.jcarousel('items').css('width', width + 'px');
    })
        .jcarousel({
            list: '.apetittv-video-slider',
            items: '.views-row',
            wrap: 'circular'
        })
        .jcarouselAutoscroll({
            interval: 4000,
            target: '+=1',
            autostart: true
        });

        jQuery('.apetittv-video-slider-pagination')
            .on('jcarouselpagination:active', 'a', function() {
                jQuery(this).addClass('active');
            })
            .on('jcarouselpagination:inactive', 'a', function() {
                jQuery(this).removeClass('active');
            })
            .jcarouselPagination({
              item: function(page) {
                  return '<a href="#' + page + '"></a>';
                  }
        });

        jQuery('.apetittv-video-slider-prev').jcarouselControl({target:'-=1'});
        jQuery('.apetittv-video-slider-next').jcarouselControl({target:'+=1'});
        jQuery('.apetittv-video-slider').hover(function() {
            jQuery(this).jcarouselAutoscroll('stop');
          }, function() {
            jQuery(this).jcarouselAutoscroll('start');
          });

    });
	
    

})(jQuery, Drupal, this, this.document); 

//krokovaci galerie
