
var VJSplayer = function(id, cfg, cfgdef) {
    var vjsplayer = this;
    this.wid = id;
    this.pid = 'vjs' + id;
    this.clickEvent = (navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/Android/i)) ? 'tap' : 'click';
    var cfgcm = jQuery.extend(true, {}, cfgdef);
    for (var a in cfg) {
        if (cfg[a] != null) {
            if (typeof cfg[a] === 'object') {
                for (var b in cfg[a]) { if (typeof cfg[a][b] === 'object') { for (var c in cfg[a][b]) { cfgcm[a][b][c] = cfg[a][b][c]; } } else { cfgcm[a][b] = cfg[a][b]; } }
            } else {
                cfgcm[a] = cfg[a];
            }
        }
    }
    this.cfg = cfgcm;
};
VJSplayer.prototype.error = function(msg, hide, log) {
    this.message = msg;
    var parent = jQuery("#" + this.wid);
    if (hide) {
        parent.find('.vjserror').remove();
    } else {
        if (log) {
            // console.log(msg);
        }
        parent.append('<div class="vjserror">' + msg + '</div>');
    }
};
VJSplayer.prototype.eventLog = function(id, player) {
    var cfg = this.cfg;
    var vjsplayer = this;
    var iteration = 0;
    var parent = this.pid;
    var clickEvent = this.clickEvent;
    var eventLog =  cfg.video.eventLog;
    var playing = false, seeking = false, seekStart = 0, seekEnd = 0, started = false, completed = false, update = false, c25 = false, c50 = false, c75 = false, c90 = false;

    var loaded = function() {
        playing = true;
        if(!!cfg.video.url) {
            jQuery("#" + parent).append('<div class="clickable" style="position:absolute;display:none;left:0;right:0;top:0;bottom:30px;width:100%;cursor:pointer;"></div>');
            jQuery("#" + parent + " .clickable").on('click touchstart', function() {
                if (eventLog.active && eventLog.click) {
                    vjsplayer.postEventLog('click',id);
                }
                var url = (cfg.video.url.indexOf("?") != -1) ? cfg.video.url + '&ord=' + (new Date()).getTime() : cfg.video.url + '?ord=' + (new Date()).getTime();
                var tab = window.open(url, '_blank');
                if (tab) tab.focus();
            });
        }
    };

    var play = function() {
        if (seeking && !playing) {
            seeking = false;
        }
        playing = true;
        seeking = false;
        if (!update) {
            player.on("timeupdate", timeupdate);
            update = true;
        }
    };

    var pause = function() {
        playing = false;
    };

    var timeupdate = function() {
        var position = player.currentTime();
        var duration = player.duration();
        var played = (duration==0) ? 0 : position/duration * 100;
        if (played>=1 && played<25 && !started && completed && cfg.video.loop && !cfg.ads.active) {
            if (eventLog.active && eventLog.reloaded) {
                if (cfg.video.replayedMax && cfg.video.replayedMax>=1) {
                    cfg.video.replayedMax--;
                    if (cfg.video.replayedMax==0) {
                        player.pause();
                        player.currentTime(0);
                    } else {
                        vjsplayer.postEventLog('reloaded',id);
                    }
                } else {
                    vjsplayer.postEventLog('reloaded',id);
                }
            }
            if (!!eventLog.startedImpx) {
                appendImpx(eventLog.startedImpx);
            }
            if(!!cfg.video.url) {
                vjsplayer.click(player,'on');
            }
            started = true;
            completed = false;
        } else if (duration>0 && !seeking && position<5 && !started) {
            if (eventLog.active && eventLog.started) {
                vjsplayer.postEventLog('started',id);
            }
            if (!!eventLog.startedImpx) {
                appendImpx(eventLog.startedImpx);
            }
            if(!!cfg.video.url) {
                vjsplayer.click(player,'on');
            }
            started = true;
            completed = false;
        }
        if (played>=25 && !c25) {
            if (eventLog.active && eventLog.complete25) {
                vjsplayer.postEventLog('25%',id);
            }
            c25 = true;
        }
        if (played>=50 && !c50) {
            if (eventLog.active && eventLog.complete50) {
                vjsplayer.postEventLog('50%',id);
            }
            c50=true;
        }
        if (played>=75 && !c75) {
            if (eventLog.active && eventLog.complete75) {
                vjsplayer.postEventLog('75%',id);
            }
            c75=true;
        }
        if (played>=90 && !c90) {
            c90 = true;
        }
        seekStart = seekEnd;
        seekEnd = position;
        if (Math.abs(seekStart-seekEnd)>1) {
            if(!seeking) {
                seeking = true;
            }
            if (seekEnd==0 && c90 && !completed) {
                if (eventLog.active && eventLog.completed) {
                    vjsplayer.postEventLog('completed',id);
                    if (cfg.video.maxloop != 0){
                        iteration += 1;
                        if (cfg.video.maxloop == iteration)  {
                            player.pause();
                            iteration = 0;
                        }
                    }
                }
                if (!!eventLog.completedImpx) {
                    appendImpx(eventLog.completedImpx);
                }
                started = false;
                c25 = false;
                c50 = false;
                c75 = false;
                c90 = false;
                completed = true;
            }
        }
    };

    var error = function() {
        vjsplayer.postEventLog('error at ' + player.currentTime() + ': ' + player.error().message,id);
    };

    var ended = function() {
        if (!completed) {
            started = false;
            c25 = false;
            c50 = false;
            c75 = false;
            c90 = false;
            completed = true;
            if (eventLog.completed) {
                vjsplayer.postEventLog('completed',id);
            }
            if (eventLog.completedImpx!='') {
                appendImpx(eventLog.completedImpx);
            }
        }
        if (cfg.video.loop) {
            vjsplayer.click(player,'off');
        }
        playing = false;
        player.off("timeupdate", timeupdate);
        update = false;
    };

    var appendImpx = function(impxSrc) {
        impxSrc = (impxSrc.indexOf("?") != -1) ? impxSrc = impxSrc + '&ord=' + (new Date()).getTime() : impxSrc = impxSrc + '?ord=' + (new Date()).getTime();
        jQuery('body').append('<img src="' + impxSrc + '" border="0" width="1" height="1" style="display: none">');
    };

    player.on("loadedmetadata", loaded);
    player.on("play", play);
    player.on("pause", pause);
    player.on("ended", ended);
    player.on("error", error);
};
VJSplayer.prototype.ima = function(player) {
    var cfg = this.cfg;
    var pid = this.pid;
    var vjsplayer = this;

    player.ima(
        //options
        {
            id: pid,
            adTagUrl: cfg.ads.vmapUrl,
            adLabel: "Reklama",
            locale: "cs"
            //        contribAdsSettings: { timeout: 2000, prerollTimeout:500, postrollTimeout:400, debug:true }
        },
        function() {
            //reload if ads
            if (cfg.video.loop && cfg.ads.active && !!cfg.ads.vmapUrl) {
                player.ima.addEventListener(google.ima.AdEvent.Type.ALL_ADS_COMPLETED,
                    function(){
                        vjsplayer.switchVideo(player,cfg.video.source.src,cfg.video.poster);
                    }
                );
            }
            //ads eventLog
            if (cfg.ads.eventLog.active || !!cfg.video.url) {
                var adId;
                player.ima.addEventListener(google.ima.AdEvent.Type.STARTED,
                    function(){
                        adId = this.getCurrentAd().getAdId();
                        if (cfg.ads.eventLog.started) {
                            vjsplayer.postEventLog('ad STARTED',adId);
                        }
                        if (!!cfg.video.url) {
                            vjsplayer.click(player,'off');
                        }
                    }
                );
                if (cfg.ads.eventLog.muted) {
                    player.ima.addEventListener(google.ima.AdEvent.Type.VOLUME_MUTED,
                        function(){
                            vjsplayer.postEventLog('ad MUTED',adId);
                        }
                    );
                }
                player.ima.addEventListener(google.ima.AdEvent.Type.SKIPPED,
                    function(){
                        if (cfg.ads.eventLog.skipped) {
                            vjsplayer.postEventLog('ad SKIPPED',adId);
                        }
                        if(!!cfg.video.url) {
                            vjsplayer.click(player,'on');
                        }
                    }
                );
                player.ima.addEventListener(google.ima.AdEvent.Type.COMPLETE,
                    function(){
                        if (cfg.ads.eventLog.completed) {
                            vjsplayer.postEventLog('ad COMPLETED',adId);
                        }
                        if(!!cfg.video.url) {
                            vjsplayer.click(player,'on');
                        }
                    }
                );
            }
            player.ima.startFromReadyCallback();
        }
    );
    // Remove controls from the player on iPad
    var contentPlayer =  document.getElementById(this.wid);
    if ((navigator.userAgent.match(/iPad/i) ||
        navigator.userAgent.match(/Android/i)) &&
        contentPlayer.hasAttribute('controls')) {
        contentPlayer.removeAttribute('controls');
    }
    player.ima.initializeAdDisplayContainer();
    player.ima.requestAds();
};
VJSplayer.prototype.postEventLog = function(method, id) {
    jQuery.ajax({
        type: 'post',
        url: "//mereni.burda.cz/api/saveevent/",
        timeout: 30000,
        crossDomain: true,
        data: {method: method, videourl: id, weburl: window.location.href},
        success: function(data, textStatus, xhr) {
            if(xhr.status == 200) {
                // console.log(200);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("err: "+textStatus);
            console.log(errorThrown);
        },
        complete: function() {
        }
    });
};
VJSplayer.prototype.click = function(player, method) {
    var clickable = jQuery("#" + this.pid).find('.clickable');
    if (method=='on') {
        clickable.css('display','block');
        //clickable[method](clickEvent, newWin);
    } else {
        clickable.css('display','none');
        //clickable[method](clickEvent);
    }
};
VJSplayer.prototype.switchVideo = function(player,src,poster) {
    player.ima.setContentWithAdTag(src,null,false);
    player.poster(poster);
    player.play();
    setTimeout(function() {
        player.ima.requestAds();
    }, 2000);
};
VJSplayer.prototype.getScripts = function(scripts, loaded, callback) {
    var vjsplayer = this;
    if (!vjscfg.require.loaded[loaded]) {
        vjscfg.require.loaded[loaded] = 'loading';
        var progress = 0;
        scripts.forEach(function(script) {
            jQuery.getScript(script, function () {
                if (++progress == scripts.length) {
                    vjscfg.require.loaded[loaded] = true;
                    callback();
                }
            });
        });
    } else if (vjscfg.require.loaded[loaded]=='loading') {
        setTimeout(function() {vjsplayer.getScripts(scripts, loaded, callback);}, 2000);
    } else {
        callback();
    }
};
VJSplayer.prototype.init = function() {
    var cfg = this.cfg;
    var pid = this.pid;
    var wid = this.wid;
    var vjsplayer = this;
    var clickEvent = this.clickEvent;
    var fileName = cfg.video.source.src.split('/').pop();

    var playVideo = function(player) {
        if(cfg.ads.active && !!cfg.ads.vmapUrl) {
            vjsplayer.getScripts(cfg.require.path.ads, 'ads', function () {
                vjsplayer.ima(player);
            });
            player.on("adsready", function(){
                player.play();
            });
        } else {
            player.play();
        }
    };

    var loadVideo = function(videocontainer) {
        if (vjscfg.require.loaded.video===true) {
            jQuery("#" + wid).empty().append(videocontainer);
            videojs(pid, cfg).ready(function() {
                var player = this;
                if(cfg.video.loop && (!cfg.ads.active || !cfg.ads.vmapUrl)) {
                    player.loop(true);
                }
                if(cfg.video.muted) {
                    player.muted(true);
                }
                if(!cfg.video.youtube) {
                    player.src(cfg.video.source.src);
                }
                if(cfg.video.autoplay) {
                    playVideo(player);
                } else {
                    player.one(clickEvent, function() {
                        playVideo(player);
                    });
                }
                if(cfg.video.eventLog.active) {
                    vjsplayer.eventLog(fileName,player);
                }
                if(!!cfg.video.url && !cfg.video.eventLog.active) {
                    vjsplayer.eventLog(fileName,player);
                }
            });
        } else {
            vjsplayer.error('Inicializace pĹ™ehrĂˇvaÄŤe se nezdaĹ™ila.', false, false);
            vjsplayer.postEventLog('error: vjsPlayer could not be initialized.',fileName);
        }
    };

    if (document.createElement('video').canPlayType) {
        //var controls = (!!cfg.video.controls && !cfg.video.youtube) ? ' controls' : '';
        //var yt_options = '"ytControls": 2';
        var controls = ' controls';
        var yt_options = '';
        var playsinline = (!!cfg.video.url) ? ' playsinline' : '';
        var videoimg = (cfg.video.poster) ? '<img src="' + cfg.video.poster + '" alt="" style="max-width:100%; width: ' + cfg.video.width + 'px"/>' : '';
        var datasetup = (!!cfg.video.youtube) ? ' data-setup=\'{ "techOrder": ["youtube"], "sources": [{ "type": "video/youtube", "src": "' + cfg.video.source.src + '"}], "youtube": { ' + yt_options + ' } }\'' : '';
        var videocontainer = jQuery('<video width="' + cfg.video.width + '" height="' + cfg.video.height + '" id="' + this.pid + '" class="video-js vjs-default-skin vjs-big-play-centered" preload="' + cfg.video.preload + '" poster = "' + cfg.video.poster + '"' + controls + datasetup + playsinline + '>');
        jQuery("#" + wid).empty().append(videoimg);
        vjsplayer.getScripts(cfg.require.path.video, 'video', function () {
            loadVideo(videocontainer);
        });
        if (!vjscfg.require.loaded.css) {
            vjscfg.require.loaded.css = true;
            for (var i = 0; i < vjscfg.require.path.css.length; i++) {
                jQuery('<link/>', {
                    rel: 'stylesheet',
                    type: 'text/css',
                    href: vjscfg.require.path.css[i]
                }).appendTo('head');
            }
        }
    } else {
        vjsplayer.error('Video nelze přehrát. Verze prohlížeče není podporována.', false, false);
        vjsplayer.postEventLog('error: Browser does not support the video tag.',fileName);
    }

};


var vjsplayer = function(id, cfg) {
    window['vjs'+id] = new VJSplayer(id, cfg, vjscfg);
    window['vjs'+id].init();
};