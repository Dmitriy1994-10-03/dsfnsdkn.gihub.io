(function ( $ )
{

    renderVjsplayer = function() {

        if($(".vjsplayer").length > 0)
        {
            setTimeout(function() {
                var vjs_vmapurl = '//mereni.burda.cz/libs/player/ads/elle/';
                $(".vjsplayer").each(function( index )
                {
                    if(!$(this).hasClass('rendered'))
                    {
                        $(this).addClass("rendered");
                        var vjs_id = $(this).attr("id");
                        var vjs_poster = $(this).attr("data-poster");
                        var vjs_src = $(this).attr("data-src");
                        var vjs_autoplay = ($(this).attr("data-autoplay") === 'true');
                        var vjs_youtube = ($(this).attr("data-youtube") === 'true');

                        if (!vjs_youtube) {
                            $.ajax({
                                type: 'HEAD',
                                url: vjs_src,
                                success: function () {
                                    vjsplayer(vjs_id, {
                                        'video': {
                                            'poster': vjs_poster,
                                            'autoplay': vjs_autoplay,
                                            'source': {
                                                'src': vjs_src
                                            }
                                        },
                                        'ads': {
                                            'vmapUrl': vjs_vmapurl
                                        }
                                    });
                                },
                                error: function () {
                                    // file not found
                                }
                            });
                        } else {
                            //youtube
                            vjsplayer(vjs_id, {
                                'video': {
                                    'poster': vjs_poster,
                                    'autoplay': vjs_autoplay,
                                    'youtube': vjs_youtube,
                                    'source': {
                                        'src': vjs_src
                                    }
                                },
                                'ads': {
                                    'vmapUrl': vjs_vmapurl
                                }
                            });
                        }
                    }
                });
            }, 3000);
        }
    };

    renderVjsplayer();

}( jQuery ));