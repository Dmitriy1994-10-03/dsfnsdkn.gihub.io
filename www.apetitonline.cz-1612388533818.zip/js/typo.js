(function ($) {
  // Show typo report window
  // TODO: move this lines to behaviors.
  // callback for Drupal ajax_command_invoke function
  $.fn.typo_js_callback = function(res) {
    $('#typo-report-message').css({'display': 'none'});
    $('#typo-report-result').css({'display': 'block'}).html('Děkujeme');
    setTimeout(modalContentClose, 1000);
  };

    $.fn.typo_js_error = function(res) {
        setTimeout(function () {
            $('#typo-report-message form .typo-error').fadeOut(3000);
        }, 3000);
    };

  /**
   * Function shows modal window.
   */
  $.fn.typo_report_window = function() {
      // Get selection context.
      var context = typo_get_sel_context();
      // Show dialog.
      $('#typo-context-div').html(context);
      $('#typo-context').val(context);
      $('#typo-url').val(window.location);

      // Close modal by Esc press.
      $(document).keydown(typo_close = function(e) {
        if (e.keyCode == 27) {
          //typo_restore_form();
          modalContentClose();
          $(document).unbind('keydown', typo_close);
        }
      });

      // Close modal by clicking outside the window.
      $('#modalBackdrop').click(typo_click_close = function(e) {
        //typo_restore_form();
        modalContentClose();
        $('#modalBackdrop').unbind('click', typo_click_close);
      });

      // Close modal by "close" link click.
      $('#close').click(function(e) {
        //typo_restore_form();
        modalContentClose();
        $(document).unbind('keydown', typo_close);
      });
  };

    Drupal.behaviors.typoReport = {
        attach : function(context, settings) {
            $.fn.typo_report_window();
        }
    };
})(jQuery);