
var vjscfg = {
  "video": {
    "autoplay": false,
    "controls": true,
    "height": 360,
    "width": 640,
    "loop": true,
    "maxloop": 5,
    "replayedMax": "",
    "muted": false,
    "poster": "",
    "preload": "auto",
    "youtube": false,
    "url": "",
    "source": {
      "src": "",
      "type": "video\/mp4",
      "media": ""
    },
    "eventLog": {
      "active": true,
      "started": true,
      "complete25": true,
      "complete50": true,
      "complete75": true,
      "completed": true,
      "reloaded": true,
      "click": true,
      "startedImpx": "",
      "completedImpx": ""
    }
  },
  "ads": {
    "active": true,
    "vmapUrl": "",
    "eventLog": {
      "active": false,
      "started": true,
      "muted": true,
      "skipped": true,
      "completed": true
    },
    "caroda": true
  },
  "require": {
    "loaded": {
      "video": false,
      "ads": false,
      "css": false
    },
    "path": {
      "video": [
        '\/\/mereni.burda.cz\/libs\/player\/video.min.js'
      ],
      "ads": [
        '\/\/imasdk.googleapis.com\/js\/sdkloader\/ima3.js',
        '\/\/mereni.burda.cz\/libs\/player\/videojs.ads.js',
        '\/\/mereni.burda.cz\/libs\/player\/videojs.ima.js'
      ],
      "css": [
        '\/\/mereni.burda.cz\/libs\/player\/video-js.min.css',
        '\/\/mereni.burda.cz\/libs\/player\/videojs.axdxs.css',
        '\/\/mereni.burda.cz\/libs\/player\/videojs.ima.css'
      ]
    }
  }
};
