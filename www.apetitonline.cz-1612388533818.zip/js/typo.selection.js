/**
 * Function gets a context of typo.
 */
function typo_get_sel_context() {
    var context = jQuery('#wrapper h2.title').first().text();
  return context;
}
