(function ($) {
  /**
   * Provide the HTML to create the modal dialog.
   * Clone of function Drupal.theme.prototype.CToolsModalDialog.
   */
  Drupal.theme.prototype.TypoModalDialog = function () {
    var html = ''
    html += '  <div id="ctools-modal" class="popups-box">'
    html += '    <div id="typo-modal">'
    html += '      <div class="ctools-modal-content ctools-modal-TypoModal-content">' // panels-modal-content
    html += '        <div class="modal-header">';
    html += '          <a id="close" href="#" onclick="return false;">';
    html +=              Drupal.CTools.Modal.currentSettings.closeText + Drupal.CTools.Modal.currentSettings.closeImage;
    html += '          </a>';
    html += '          <span id="modal-title" class="modal-title"></span>';
    html += '        </div>';
    html += '<div id="typo-message">Nahlašujete chybu v následujícím receptu:'
    html += ' <div id="typo-context-div"></div></div>';
    html += '        <div id="modal-content" class="modal-content">';
    html += '        </div>';
    html += '      </div>';
    html += '    </div>';
    html += '  </div>';

    return html;
  }
})(jQuery);